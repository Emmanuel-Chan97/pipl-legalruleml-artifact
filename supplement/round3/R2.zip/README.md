# 《个人信息保护法》全法模型 · 第二轮精简

编辑 `PIPL-model.json`。双击 `view.html`，选取同目录的 JSON，即可按条号或记录 ID 查看原文、八个标注问题、字段判断和出处。阅读器默认打开第57条的个人通知豁免；浏览过程在本机完成。HTML 没有另存一份法条数据。`PIPL-role-label.lrml` 是从本版模型生成的 LegalRuleML 交换文件。

## 去哪里填写

| 要表达的内容 | 保存位置 |
|---|---|
| 谁在这条规范中担任什么角色 | `participants`。每个条目只有 `role` 与 `label`。整组参与者共用的出处、判定依据在 `field_annotations.participants`。 |
| 行为、触发事实、时间、适用范围或法律效果 | 沿用 `content_expr`、`activation`、`temporal`、`applicability`、`effects`。相应字段的依据和说明在同名的 `field_annotations` 项下。 |
| 义务、禁止、许可，或对行为算子适用性的判断 | 原生 XML 元素仍由 `legalruleml.native_element` 指定。判断依据放在 `field_annotations.conduct_force`。缺少专门 `note` 时沿用 `linguistic_form.scope_note`。单条记录有独立理由时写入专门说明。 |
| 例外条件、所关联的记录和法律目标 | 在顶层 `exceptions[]` 编辑。用 `record_refs` 表示关联记录，用 `target_ids` 表示法律作用目标。字段标注只保存判断的依据。回读旧结构时，目标列表按原顺序汇总，兼容有独立目标说明的旧数据。 |
| 某一判断的依据与出处 | `basis` 说明是原文明示、跨条援引、解释重构等，`coverage` 说明依据的精度或覆盖范围。重复的状态可只填 `answer_state`。字段的 `anchor_refs` 按顺序指向顶层 `source_anchor_catalog`。 |
| 界面显示的问题 | 顶层 `question_catalog` 保留已有提示语和问题 ID。`annotation_slot` 指明读取哪个字段的标注。每条显示八个问题，道义作用项在两种问法中选择一种。 |

当前205条记录共有1,640份字段标注。2,111次依据引用指向407个不同的完整锚点。只有当法条版本、位置、用途及其他锚点信息都相同时才共用一项。修改一个共享锚点会影响它的全部引用。如仅纠正某个字段的出处，应让该字段引用另一项锚点。锚点 ID 在初次迁移时根据完整内容生成；在本版内直接编辑已有锚点时，可继续沿用其 ID。切勿只按引文字面内容合并不同法律用途。

有657份回答原来同时保存相同的 `answer_state` 和 `coverage`，且无原文锚点，本版将相同状态存一次。584份表示“尚未单独标注”，73份表示“不适用”。原有的判定理由、独立覆盖范围或专属引文继续保留。

## 第57条例子

打开阅读器并查找 `57.1a`，展开时间问题的“说明与出处”，可读到“应当立即采取补救措施”。`temporal[].applies_to` 标识这处时间限定所修饰的动作。查找 `57.2a`，则可分别查看“可以不通知个人”的道义判断和该豁免的目标。二者引用同一处原文，对例外的判断还引用一般通知规范。它特有的道义说明存放在 `field_annotations.conduct_force.note`，其他204条按现有数据共用相应记录的 `linguistic_form.scope_note`。第13条等七项关于为何未采用义务、许可或禁止算子的实质理由也完整保留。

## 兼容与核验

`storage_profile` 为 `pipl-field-annotations-r2`。第一轮集中保存的原文片段、例外、法律地位关系、效果和通用审校说明继续使用原来的维护位置。为使旧阅读器和导出器可用，旧问题名仍是提示目录中的稳定 ID。既有说明中所说的 `source_quote`、`/exceptions`、`coverage` 等旧路径可通过展开视图读取；在当前数据中分别由片段引用、集中例外表、以及已保存的覆盖或状态字段解析得到。

在解压目录中运行。转换仅需 Python 标准库，验证和 XML 导出另需 lxml。随包附离线验证所用的 OASIS Compact XSD。

```shell
python3 verify.py
python3 migrate.py to-r1 PIPL-model.json round1.json
python3 migrate.py expand PIPL-model.json expanded.json
python3 exporter/export_native.py PIPL-model.json output.lrml
```

已有旧文件时，`compact` 接受第一轮 JSON 或展开版 JSON，可重建第二轮文件。也可指定相应的实物基线比对完整数据。

```shell
python3 migrate.py compact round1.json rebuilt.json
python3 verify.py --baseline-r1 round1.json
```

`verify.py` 检查本次发布的两级 JSON 完整还原、XML 字节和结构、原文引用、例外目标与七项道义判断理由。它还特意把第57条的 XML 豁免目标从“通知个人”改到“通知部门”，确认 XSD 接受该结构、独立的项目检查检出错误。以后有意修改模型内容后，可单独用 `python3 qa/profile.py output.lrml --pilot` 验证重新导出的 XML。本次全量等价检查覆盖包括项目专有标注在内的全部 JSON。Compact XSD 与试点解释检查分别覆盖 XML 结构和预先设定的解释条件。

[OASIS LegalRuleML Core Specification 1.0](https://docs.oasis-open.org/legalruleml/legalruleml-core-spec/v1.0/os/legalruleml-core-spec-v1.0-os.html) · [《中华人民共和国个人信息保护法》中文原文](https://www.cac.gov.cn/2021-08/20/c_1631050028355286.htm)
